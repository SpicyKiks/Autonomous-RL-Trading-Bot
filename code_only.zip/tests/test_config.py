def test_import_package():
    import autonomous_rl_trading_bot  # noqa: F401
