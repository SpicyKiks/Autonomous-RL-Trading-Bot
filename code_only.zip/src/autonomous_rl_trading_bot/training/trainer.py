# src/autonomous_rl_trading_bot/training/trainer.py
from __future__ import annotations

from dataclasses import dataclass, fields as dc_fields
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from autonomous_rl_trading_bot.common.fs import ensure_dir, write_json
from autonomous_rl_trading_bot.common.hashing import dataset_hash
from autonomous_rl_trading_bot.common.logging import get_logger
from autonomous_rl_trading_bot.evaluation.metrics import compute_metrics
from autonomous_rl_trading_bot.evaluation.reporting import generate_run_report
from autonomous_rl_trading_bot.repro.repro import build_repro_payload
from autonomous_rl_trading_bot.rl.dataset import Dataset
from autonomous_rl_trading_bot.rl.env_trading import TradingEnv, TradingEnvConfig

from stable_baselines3 import A2C, DQN, PPO

logger = get_logger(__name__)


def _asdict_dataclass(obj: Any) -> Dict[str, Any]:
    if not hasattr(obj, "__dataclass_fields__"):
        raise TypeError("Expected a dataclass instance")
    return {f.name: getattr(obj, f.name) for f in dc_fields(obj)}


# =========================
# Config
# =========================
@dataclass(frozen=True)
class TrainConfig:
    # dataset selection
    dataset_id: str

    # core training args
    mode: str  # "spot" | "futures"
    algo: str  # "ppo" | "a2c" | "dqn"
    timesteps: int
    seed: int

    # splits (relative weights; will be normalized)
    train_split: int = 8
    eval_split: int = 2

    # env/hparams
    device: str = "cpu"
    lookback: int = 64
    fee_bps: float = 10.0
    slippage_bps: float = 0.0

    # capital / sizing
    initial_cash: float = 1000.0
    initial_equity: Optional[float] = None  # alias to initial_cash (wins if provided)
    position_fraction: float = 1.0          # fraction of equity to deploy per trade/step
    futures_leverage: float = 1.0           # only used for futures mode (if env supports)

    # outputs
    artifacts_dir: str = "artifacts"
    run_name: Optional[str] = None

    # evaluation
    eval_episodes: int = 1

    # logging
    log_level: str = "INFO"

    def __post_init__(self) -> None:
        if self.train_split <= 0 or self.eval_split <= 0:
            raise ValueError("train_split and eval_split must be > 0")

        if self.lookback <= 0:
            raise ValueError("lookback must be > 0")

        if self.timesteps <= 0:
            raise ValueError("timesteps must be > 0")

        if float(self.position_fraction) <= 0 or float(self.position_fraction) > 1.0:
            raise ValueError("position_fraction must be in (0, 1].")

        if float(self.futures_leverage) <= 0:
            raise ValueError("futures_leverage must be > 0.")

        # unify naming: if initial_equity is provided, it wins.
        if self.initial_equity is not None:
            object.__setattr__(self, "initial_cash", float(self.initial_equity))


def _make_algo(algo: str):
    a = algo.lower().strip()
    if a == "ppo":
        return PPO
    if a == "a2c":
        return A2C
    if a == "dqn":
        return DQN
    raise ValueError(f"Unknown algo '{algo}'. Expected one of: ppo, a2c, dqn")


def _split_dataset(ds: Dataset, train_split: float, eval_split: float) -> Tuple[Dataset, Dataset]:
    if train_split <= 0 or eval_split <= 0:
        raise ValueError("train_split and eval_split must be > 0")

    total = float(train_split + eval_split)
    train_frac = float(train_split) / total

    # Dataset is expected to implement split_time(train_frac=...)
    train_ds, eval_ds = ds.split_time(train_frac=train_frac)
    return train_ds, eval_ds


def _make_env_config(cfg: TrainConfig) -> TradingEnvConfig:
    """
    Build TradingEnvConfig but only pass keys it actually supports.
    This makes trainer resilient when env config changes.
    """
    env_cfg_kwargs: Dict[str, Any] = {
        "mode": cfg.mode,
        "lookback": cfg.lookback,
        "fee_bps": cfg.fee_bps,
        "slippage_bps": cfg.slippage_bps,
        "initial_cash": cfg.initial_cash,
        "seed": cfg.seed,
        "position_fraction": cfg.position_fraction,
        "futures_leverage": cfg.futures_leverage,
    }

    allowed = {f.name for f in dc_fields(TradingEnvConfig)}
    filtered = {k: v for k, v in env_cfg_kwargs.items() if k in allowed}
    return TradingEnvConfig(**filtered)


def train_and_evaluate(cfg: TrainConfig) -> Dict[str, Any]:
    """
    End-to-end training + evaluation run.
    Produces:
      - artifacts folder with config/repro/metrics/report
      - returns a dict payload summarising the run
    """
    # --- load dataset ---
    ds = Dataset.load(cfg.dataset_id)
    ds_hash = dataset_hash(ds)

    # --- run naming / folders ---
    run_name = cfg.run_name or f"{cfg.mode}_{cfg.algo}_seed{cfg.seed}_{ds_hash[:8]}"
    artifacts_root = Path(cfg.artifacts_dir)
    run_dir = artifacts_root / run_name
    ensure_dir(run_dir)

    # --- split ---
    train_ds, eval_ds = _split_dataset(ds, cfg.train_split, cfg.eval_split)

    # --- env config ---
    env_cfg = _make_env_config(cfg)

    # --- build envs ---
    train_env = TradingEnv(train_ds, env_cfg)
    eval_env = TradingEnv(eval_ds, env_cfg)

    # --- model ---
    AlgoCls = _make_algo(cfg.algo)
    model = AlgoCls(
        "MlpPolicy",
        train_env,
        verbose=1,
        seed=cfg.seed,
        device=cfg.device,
    )

    # --- train ---
    logger.info("Training started: algo=%s timesteps=%s device=%s", cfg.algo, cfg.timesteps, cfg.device)
    model.learn(total_timesteps=int(cfg.timesteps))
    logger.info("Training finished")

    # --- evaluation rollout ---
    logger.info("Evaluation started: episodes=%s", cfg.eval_episodes)

    all_episode_infos: list[Dict[str, Any]] = []
    for _ in range(int(cfg.eval_episodes)):
        obs, _ = eval_env.reset()
        done = False
        truncated = False
        while not (done or truncated):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, done, truncated, info = eval_env.step(action)
            if isinstance(info, dict):
                all_episode_infos.append(info)

    metrics = compute_metrics(all_episode_infos)

    # --- repro payload ---
    repro = build_repro_payload()

    # --- persist artifacts ---
    write_json(run_dir / "train_config.json", _asdict_dataclass(cfg))
    write_json(run_dir / "dataset.json", {"dataset_id": cfg.dataset_id, "dataset_hash": ds_hash})
    write_json(run_dir / "metrics.json", metrics)
    write_json(run_dir / "repro.json", repro)

    report_path = generate_run_report(
        out_dir=run_dir,
        run_name=run_name,
        train_config=_asdict_dataclass(cfg),
        dataset={"dataset_id": cfg.dataset_id, "dataset_hash": ds_hash},
        metrics=metrics,
        repro=repro,
    )

    payload: Dict[str, Any] = {
        "run_name": run_name,
        "run_dir": str(run_dir),
        "dataset_id": cfg.dataset_id,
        "dataset_hash": ds_hash,
        "metrics": metrics,
        "report_path": str(report_path) if report_path is not None else None,
    }
    return payload
