from __future__ import annotations

from autonomous_rl_trading_bot.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
