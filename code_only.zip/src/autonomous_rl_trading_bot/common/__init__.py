from __future__ import annotations

# Common utilities and types

