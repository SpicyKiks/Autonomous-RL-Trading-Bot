class ConfigError(RuntimeError):
    pass


class PathError(RuntimeError):
    pass
