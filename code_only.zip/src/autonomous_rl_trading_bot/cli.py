#!/usr/bin/env python3
"""
Unified CLI entrypoint for autonomous-rl-trading-bot.

Usage:
    python -m autonomous_rl_trading_bot <command> [args...]
    arbt <command> [args...]
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from autonomous_rl_trading_bot.version import __version__


def _dispatch_dataset_fetch(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_fetch_data.main()."""
    from run_fetch_data import main

    return main(argv)


def _dispatch_dataset_build(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_build_dataset.main()."""
    from run_build_dataset import main

    return main(argv)


def _dispatch_backtest(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_backtest.main()."""
    from autonomous_rl_trading_bot.run_backtest import main

    return main(argv)


def _dispatch_train(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_train.main()."""
    from autonomous_rl_trading_bot.run_train import main

    return main(argv)


def _dispatch_live(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_live_demo.main()."""
    from run_live_demo import main

    return main(argv)


def _dispatch_dashboard(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_dashboard.main()."""
    from run_dashboard import main

    return main(argv)


def _dispatch_baselines(argv: Optional[list[str]] = None) -> int:
    """Dispatch to run_baselines.main()."""
    from run_baselines import main

    return main(argv)


def _parse_args(argv: Optional[list[str]] = None) -> tuple[argparse.Namespace | None, list[str]]:
    """
    Internal helper to parse CLI arguments.
    
    Returns:
        (args, remainder) tuple. args is None if argparse called sys.exit().
    """
    parser = argparse.ArgumentParser(
        prog="arbt",
        description="Autonomous RL Trading Bot - Unified CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"autonomous-rl-trading-bot v{__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands", metavar="COMMAND")

    # dataset subcommands
    dataset_parser = subparsers.add_parser(
        "dataset",
        help="Dataset operations",
        description="Dataset operations (fetch, build)",
    )
    dataset_subparsers = dataset_parser.add_subparsers(dest="dataset_subcommand", help="Dataset subcommands", metavar="SUBCOMMAND")
    dataset_subparsers.add_parser(
        "fetch",
        help="Fetch market data from exchange",
        description="Fetch Binance klines and store into SQLite",
    )
    dataset_subparsers.add_parser(
        "build",
        help="Build dataset from stored candles",
        description="Build a clean contiguous dataset from DB candles",
    )

    # backtest
    subparsers.add_parser(
        "backtest",
        help="Run backtest evaluation",
        description="Run deterministic offline backtest",
    )

    # train
    subparsers.add_parser(
        "train",
        help="Train RL model",
        description="Train RL model using stable-baselines3",
    )

    # live
    subparsers.add_parser(
        "live",
        help="Run live (paper) trading",
        description="Run live (paper) trading on closed candles",
    )

    # dashboard
    subparsers.add_parser(
        "dashboard",
        help="Launch dashboard",
        description="Launch Dash dashboard for viewing results",
    )

    # baselines (bonus)
    subparsers.add_parser(
        "baselines",
        help="Run baseline strategies",
        description="Run baseline strategies on test split",
    )

    # Parse only known args to get command
    # Use parse_known_args to avoid consuming --help prematurely
    try:
        args, remainder = parser.parse_known_args(argv)
        return args, remainder
    except SystemExit:
        # argparse called sys.exit() (e.g., for --help)
        return None, []


def main(argv: Optional[list[str]] = None) -> int:
    """
    Main CLI entrypoint.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:]).

    Returns:
        Exit code (0 for success, non-zero for error).
    """
    if argv is None:
        argv = sys.argv[1:]

    # Handle version flag early
    if argv and "--version" in argv:
        print(f"autonomous-rl-trading-bot v{__version__}")
        return 0

    # Handle empty argv
    if not argv:
        argv = ["--help"]

    # Handle --help for subcommands before argparse consumes it
    # Pattern: <command> --help or <command> -h
    # For dataset: dataset <subcommand> --help
    if len(argv) >= 2:
        if argv[0] == "dataset" and len(argv) >= 3:
            # Pattern: dataset <subcommand> --help
            if argv[2] in ("--help", "-h"):
                subcommand = argv[1]
                if subcommand == "fetch":
                    return _dispatch_dataset_fetch(["--help"])
                if subcommand == "build":
                    return _dispatch_dataset_build(["--help"])
        elif argv[1] in ("--help", "-h"):
            # Pattern: <command> --help
            command = argv[0]
            if command == "backtest":
                return _dispatch_backtest(["--help"])
            elif command == "train":
                return _dispatch_train(["--help"])
            elif command == "live":
                return _dispatch_live(["--help"])
            elif command == "dashboard":
                return _dispatch_dashboard(["--help"])
            elif command == "baselines":
                return _dispatch_baselines(["--help"])

    args, remainder = _parse_args(argv)
    
    if args is None:
        # argparse called sys.exit() (e.g., for --help)
        return 0

    # Dispatch to appropriate handler
    command = args.command

    if command == "dataset":
        dataset_subcommand = getattr(args, "dataset_subcommand", None)
        if dataset_subcommand == "fetch":
            # If --help is in remainder, forward it
            if "--help" in remainder or "-h" in remainder:
                return _dispatch_dataset_fetch(["--help"])
            return _dispatch_dataset_fetch(remainder)
        if dataset_subcommand == "build":
            if "--help" in remainder or "-h" in remainder:
                return _dispatch_dataset_build(["--help"])
            return _dispatch_dataset_build(remainder)
        # If no subcommand, show help
        dataset_parser.print_help()
        return 1

    if command == "backtest":
        if "--help" in remainder or "-h" in remainder:
            return _dispatch_backtest(["--help"])
        return _dispatch_backtest(remainder)

    if command == "train":
        if "--help" in remainder or "-h" in remainder:
            return _dispatch_train(["--help"])
        return _dispatch_train(remainder)

    if command == "live":
        if "--help" in remainder or "-h" in remainder:
            return _dispatch_live(["--help"])
        return _dispatch_live(remainder)

    if command == "dashboard":
        if "--help" in remainder or "-h" in remainder:
            return _dispatch_dashboard(["--help"])
        return _dispatch_dashboard(remainder)

    if command == "baselines":
        if "--help" in remainder or "-h" in remainder:
            return _dispatch_baselines(["--help"])
        return _dispatch_baselines(remainder)

    # No command provided
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

