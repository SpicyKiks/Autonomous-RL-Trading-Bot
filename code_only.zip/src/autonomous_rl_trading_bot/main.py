from .version import __version__


def main() -> None:
    print(f"autonomous-rl-trading-bot v{__version__}")


if __name__ == "__main__":
    main()
